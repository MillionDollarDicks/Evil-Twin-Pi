#!/bin/bash

sudo killall hostapd
sudo killall dnsmasq
sudo killall python
airmon-ng stop wlan1mon
airmon-ng stop wlan2mon
sudo service dhcpcd restart