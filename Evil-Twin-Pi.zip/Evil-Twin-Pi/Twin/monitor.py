import os, sys, time, subprocess
import RPi.GPIO as GPIO

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

GPIO.setup(22,GPIO.OUT) #RED
GPIO.setup(17,GPIO.OUT) #BLUE

def led_on(x):
    GPIO.output(x,GPIO.HIGH)

def led_off(x):
    GPIO.output(x,GPIO.LOW)

red=int(22)
blue=int(17)

led_on(red) #Attack running

while 1:
        passwd = open('/var/www/html/data.txt','r')
        read_passwd = passwd.read()
        if read_passwd !='':

		led_off(red)
		led_on(blue)
		os.system('./stop-AP.sh')
		break

	time.sleep(1)
